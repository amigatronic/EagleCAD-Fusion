import unittest

from geometry import BoardData, ComponentData
from optimizer import PlacementOptimizer


def component(name, x, y=5.0, *, locked=False, is_tht=False, mirror=False):
    return ComponentData(
        name=name, library="test", package="0402", x=float(x), y=float(y),
        rot=0.0, mirror=mirror, width=1.0, height=1.0,
        offset_x=0.0, offset_y=0.0, locked=locked, is_tht=is_tht,
        is_smd=not is_tht, deviceset="R",)


class Phase6BStrategicSearchTests(unittest.TestCase):
    def test_three_component_chain_is_validated_as_one_final_state(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (30, 0), (30, 15), (0, 15), (0, 0)]]
        board.components = {
            "R1": component("R1", 3),
            "R2": component("R2", 8),
            "R3": component("R3", 13),
        }
        optimizer = PlacementOptimizer(board)
        candidates = {
            "R1": (18.0, 5.0, 0.0, False),
            "R2": (3.0, 5.0, 0.0, False),
            "R3": (8.0, 5.0, 0.0, False),
        }
        before = {name: (part.x, part.y) for name, part in board.components.items()}
        self.assertTrue(optimizer._candidate_group_is_valid(candidates))
        self.assertEqual(before, {name: (part.x, part.y) for name, part in board.components.items()})

    def test_three_component_chain_rejects_locked_component(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (30, 0), (30, 15), (0, 15), (0, 0)]]
        board.components = {
            "R1": component("R1", 3),
            "R2": component("R2", 8, locked=True),
            "R3": component("R3", 13),
        }
        optimizer = PlacementOptimizer(board)
        candidates = {
            "R1": (18.0, 5.0, 0.0, False),
            "R2": (3.0, 5.0, 0.0, False),
            "R3": (8.0, 5.0, 0.0, False),
        }
        self.assertFalse(optimizer._candidate_group_is_valid(candidates))

    def test_three_component_chain_rejects_final_position_outside_outline(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (30, 0), (30, 15), (0, 15), (0, 0)]]
        board.components = {
            "R1": component("R1", 3),
            "R2": component("R2", 8),
            "R3": component("R3", 13),
        }
        optimizer = PlacementOptimizer(board)
        candidates = {
            "R1": (40.0, 5.0, 0.0, False),
            "R2": (3.0, 5.0, 0.0, False),
            "R3": (8.0, 5.0, 0.0, False),
        }
        self.assertFalse(optimizer._candidate_group_is_valid(candidates))


if __name__ == "__main__":
    unittest.main()
