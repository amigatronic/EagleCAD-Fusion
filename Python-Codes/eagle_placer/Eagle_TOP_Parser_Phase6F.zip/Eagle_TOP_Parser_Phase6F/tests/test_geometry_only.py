import os
import tempfile
import unittest

import matplotlib
matplotlib.use("Agg", force=True)
from matplotlib.figure import Figure

from geometry import BoardData, TrackSegment
from main import classify_board_content
from parser import EagleBoardParser
from gui import EagleGUI


class GeometryOnlyBoardTests(unittest.TestCase):
    def _parse_xml(self, xml):
        handle = tempfile.NamedTemporaryFile("w", suffix=".brd", encoding="utf-8", delete=False)
        try:
            handle.write(xml)
            handle.close()
            return EagleBoardParser(handle.name).extract_data()
        finally:
            try:
                os.unlink(handle.name)
            except FileNotFoundError:
                pass

    def test_tracks_without_contactrefs_are_preserved(self):
        xml = """<eagle><drawing><board>
          <plain>
            <wire x1="0" y1="0" x2="20" y2="0" layer="20"/>
            <wire x1="20" y1="0" x2="20" y2="10" layer="20"/>
            <wire x1="20" y1="10" x2="0" y2="10" layer="20"/>
            <wire x1="0" y1="10" x2="0" y2="0" layer="20"/>
          </plain>
          <elements/><libraries/>
          <signals><signal name="N1">
            <wire x1="1" y1="1" x2="5" y2="1" width="0.5" layer="1"/>
            <wire x1="5" y1="1" x2="5" y2="4" width="0" layer="16"/>
          </signal></signals>
        </board></drawing></eagle>"""
        board = self._parse_xml(xml)
        self.assertEqual(len(board.components), 0)
        self.assertEqual(len(board.tracks), 1)
        self.assertEqual(board.tracks[0].layer, 1)
        self.assertAlmostEqual(board.tracks[0].width, 0.5)
        status, counts = classify_board_content(board)
        self.assertEqual(status, "geometry_only")
        self.assertEqual(counts["tracks"], 1)

    def test_board_without_components_or_geometry_is_classified_empty(self):
        status, counts = classify_board_content(BoardData())
        self.assertEqual(status, "empty")
        self.assertEqual(counts["components"], 0)

    def test_geometry_only_board_renders_tracks_and_outline(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (20, 0), (20, 10), (0, 10), (0, 0)]]
        board.restrict_top = [[(2, 2), (4, 2), (4, 4), (2, 4), (2, 2)]]
        board.restrict_bottom = [[(10, 2), (12, 2), (12, 4), (10, 4), (10, 2)]]
        board.tracks = [
            TrackSegment((1, 1), (15, 1), 0.5, 1),
            TrackSegment((15, 1), (15, 8), 0.5, 16),
            TrackSegment((15, 8), (5, 8), 0.3, 2),
        ]

        class DummyButton:
            def configure(self, **kwargs):
                self.state = kwargs.get("state")

        class DummyCanvas:
            def draw(self):
                pass

        gui = EagleGUI.__new__(EagleGUI)
        gui.board_data = board
        gui.optimizer = None
        gui._optimizer_running = False
        gui.btn_optimize = DummyButton()
        gui.schematic_parts = {}
        gui.dru_file_path = "skip"
        gui.design_rules = None
        gui.current_scale = "fit"
        gui.file_path = "geometry_only.brd"
        gui.fig = Figure()
        gui.canvas = DummyCanvas()
        gui._update_legend_visibility = lambda: None
        gui._apply_layer_visibility = lambda: None
        gui._render({})

        self.assertEqual(gui.btn_optimize.state, "disabled")
        self.assertEqual(len(gui.layer_artists["Copper TOP"]), 1)
        self.assertEqual(len(gui.layer_artists["Copper BOTTOM"]), 1)
        self.assertEqual(len(gui.layer_artists["Copper Inner"]), 1)
        self.assertEqual(len(gui.layer_artists["Restrict TOP"]), 1)
        self.assertEqual(len(gui.layer_artists["Restrict BOTTOM"]), 1)
        self.assertTrue(gui.ax.get_xlim()[1] > gui.ax.get_xlim()[0])
        self.assertTrue(gui.ax.get_ylim()[1] > gui.ax.get_ylim()[0])


if __name__ == "__main__":
    unittest.main()
