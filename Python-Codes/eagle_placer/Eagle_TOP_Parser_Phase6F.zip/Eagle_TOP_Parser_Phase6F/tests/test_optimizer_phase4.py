import math
import unittest
from geometry import BoardData, ComponentData, NetConnection, NetSignal
from optimizer import PlacementOptimizer


def comp(name, x, y=0.0, *, rot=0.0, locked=False, package="IC_SOIC", deviceset="DUAL_OPAMP"):
    return ComponentData(name=name, library="analog", package=package, x=x, y=y,
                         rot=rot, mirror=False, width=3.0, height=2.0,
                         offset_x=0.0, offset_y=0.0, locked=locked, is_tht=False,
                         deviceset=deviceset)


class Phase4StrategyTests(unittest.TestCase):
    def test_rotation_candidate_rotates_pad_coordinates_in_fitness(self):
        board = BoardData()
        board.components = {"U1": comp("U1", 10, 10)}
        board.signals = {"N1": NetSignal("N1", [NetConnection("U1", "1", 11, 10),
                                                        NetConnection("X", "1", 10, 20)])}
        optimizer = PlacementOptimizer(board)
        fitness_0 = optimizer.calculate_fitness()
        fitness_90 = optimizer.calculate_fitness({"U1": (10, 10, 90)})
        self.assertNotEqual(fitness_0, fitness_90)

    def test_connection_coordinates_rotate_when_rotation_is_committed(self):
        board = BoardData()
        board.components = {"U1": comp("U1", 10, 10)}
        board.signals = {"N1": NetSignal("N1", [NetConnection("U1", "1", 11, 10)])}
        optimizer = PlacementOptimizer(board)
        optimizer._transform_connections("U1", (10, 10), (10, 10), 0, 90)
        conn = board.signals["N1"].connections[0]
        self.assertAlmostEqual(conn.x, 10.0)
        self.assertAlmostEqual(conn.y, 11.0)

    def test_device_exchange_requires_verified_equivalence(self):
        first = comp("U1", 0, deviceset="DUAL_OPAMP")
        same = comp("U2", 10, deviceset="DUAL_OPAMP")
        different = comp("U3", 20, deviceset="MCU")
        self.assertTrue(PlacementOptimizer._same_physical_interface(first, same))
        self.assertFalse(PlacementOptimizer._same_physical_interface(first, different))

    def test_locked_component_is_not_rotatable(self):
        locked = comp("U1", 10, locked=True)
        optimizer = PlacementOptimizer(BoardData())
        self.assertFalse(optimizer._single_candidate_is_valid(locked, (10, 10, 90)))

    def test_layer_flip_is_rejected_for_surface_mount_component(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (20, 0), (20, 20), (0, 20), (0, 0)]]
        board.components = {"U1": comp("U1", 5, y=5)}
        optimizer = PlacementOptimizer(board)
        candidate = (5.0, 5.0, 0.0, True)
        self.assertFalse(optimizer._single_candidate_is_valid(board.components["U1"], candidate))

    def test_through_hole_component_cannot_change_layer(self):
        board = BoardData()
        through_hole = comp("J1", 5, y=5)
        through_hole.is_tht = True
        board.components = {"J1": through_hole}
        optimizer = PlacementOptimizer(board)
        self.assertFalse(optimizer._single_candidate_is_valid(through_hole, (5, 5, 0, True)))


if __name__ == "__main__":
    unittest.main()
