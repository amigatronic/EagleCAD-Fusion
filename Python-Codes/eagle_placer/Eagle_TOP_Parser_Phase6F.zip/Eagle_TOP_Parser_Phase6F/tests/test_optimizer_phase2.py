import unittest
from unittest.mock import patch

from geometry import BoardData, ComponentData, NetConnection, NetSignal
from optimizer import PlacementOptimizer, VirtualPlacementWorkspace


def component(name, x, locked=False):
    return ComponentData(
        name=name, library="test", package="0402", x=float(x), y=0.0,
        rot=0.0, mirror=False, width=1.0, height=1.0,
        offset_x=0.0, offset_y=0.0, locked=locked, is_tht=False, is_smd=True,
    )


class Phase2OptimizerTests(unittest.TestCase):
    def test_package_outline_is_used_and_transformed_with_rotation_and_mirror(self):
        board = BoardData()
        comp = component("U1", 10.0)
        comp.y = 20.0
        comp.width = 10.0
        comp.height = 10.0
        comp.package_outlines = [[(-2.0, -1.0), (2.0, -1.0), (2.0, 1.0), (-2.0, 1.0)]]
        board.components[comp.name] = comp
        optimizer = PlacementOptimizer(board)

        footprint = optimizer._component_polygon(comp, x=10.0, y=20.0, rot=90.0)
        self.assertAlmostEqual(footprint.bounds[0], 9.0, places=6)
        self.assertAlmostEqual(footprint.bounds[2], 11.0, places=6)
        self.assertAlmostEqual(footprint.bounds[1], 18.0, places=6)
        self.assertAlmostEqual(footprint.bounds[3], 22.0, places=6)

        mirrored = optimizer._component_polygon(comp, x=10.0, y=20.0, rot=0.0, mirror=True)
        self.assertAlmostEqual(mirrored.bounds[0], 8.0, places=6)
        self.assertAlmostEqual(mirrored.bounds[2], 12.0, places=6)

    def test_single_candidate_rejects_new_overlap_instead_of_grandfathering_it(self):
        board = BoardData()
        first = component("R1", 0.0)
        second = component("R2", 3.0)
        first.package_outlines = [[(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)]]
        second.package_outlines = [[(-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)]]
        board.components = {"R1": first, "R2": second}
        optimizer = PlacementOptimizer(board)
        self.assertFalse(optimizer._single_candidate_is_valid(first, (2.5, 0.0, 0.0, False)))

    def test_locked_component_is_never_moved(self):
        board = BoardData()
        board.components = {
            "R1": component("R1", 0),
            "J1": component("J1", 5, locked=True),
            "R2": component("R2", 10),
            "R3": component("R3", 15),
        }
        board.signals = {
            "N1": NetSignal("N1", [
                NetConnection("R1", "1", 0, 0),
                NetConnection("R2", "1", 10, 0),
            ]),
            "N2": NetSignal("N2", [
                NetConnection("J1", "1", 5, 0),
                NetConnection("R3", "1", 15, 0),
            ]),
        }
        locked_before = (board.components["J1"].x, board.components["J1"].y)
        optimizer = PlacementOptimizer(board)
        optimizer.optimize(max_iterations=20, max_evaluations=500)
        self.assertEqual((board.components["J1"].x, board.components["J1"].y), locked_before)
        self.assertFalse(optimizer._candidate_is_valid(
            board.components["J1"], (0, 0), board.components["R1"], (5, 0)
        ))

    def test_optimizer_reduces_ratsnest_with_legal_exchange(self):
        board = BoardData()
        board.components = {
            "R1": component("R1", 0),
            "R2": component("R2", 20),
            "R3": component("R3", 5),
            "R4": component("R4", 15),
        }
        board.signals = {
            "N1": NetSignal("N1", [
                NetConnection("R1", "1", 0, 0),
                NetConnection("R2", "1", 20, 0),
            ]),
            "N2": NetSignal("N2", [
                NetConnection("R3", "1", 5, 0),
                NetConnection("R4", "1", 15, 0),
            ]),
        }
        optimizer = PlacementOptimizer(board)
        before = optimizer.calculate_ratsnest_length()
        result = optimizer.optimize(max_iterations=30, max_evaluations=500)
        after = optimizer.calculate_ratsnest_length()
        self.assertLess(after, before)
        self.assertAlmostEqual(after, result["final_fitness"])
        self.assertGreater(result["accepted_swaps"], 0)


    def test_board_only_components_remain_eligible_without_schematic(self):
        board = BoardData()
        board.components = {
            "R1": component("R1", 0),
            "R2": component("R2", 20),
            "R3": component("R3", 5),
        }
        board.signals = {
            "N1": NetSignal("N1", [
                NetConnection("R1", "1", 0, 0),
                NetConnection("R2", "1", 20, 0),
            ]),
            "N2": NetSignal("N2", [
                NetConnection("R2", "2", 20, 1),
                NetConnection("R3", "1", 5, 0),
            ]),
        }
        # An empty orphan set represents board-only mode when no usable schematic exists.
        board.orphan_components = set()
        optimizer = PlacementOptimizer(board)
        before = optimizer.calculate_ratsnest_length()
        result = optimizer.optimize(max_iterations=20, max_evaluations=100, seed=11)
        self.assertGreater(before, 0.0)
        self.assertGreater(result["evaluations"], 0)
        self.assertEqual(result["staged_components"], 3)
        self.assertGreaterEqual(result["final_fitness"], 0.0)

    def test_orphan_component_is_fixed_and_excluded_from_fitness(self):
        board = BoardData()
        board.components = {"R1": component("R1", 0), "LOGO1": component("LOGO1", 50)}
        board.orphan_components = {"LOGO1"}
        board.signals = {"N1": NetSignal("N1", [
            NetConnection("R1", "1", 0, 0), NetConnection("LOGO1", "1", 50, 0)
        ])}
        optimizer = PlacementOptimizer(board)
        self.assertEqual(optimizer.calculate_ratsnest_length(), 0.0)
        before = (board.components["LOGO1"].x, board.components["LOGO1"].y)
        optimizer.optimize(max_iterations=10, max_evaluations=100)
        self.assertEqual((board.components["LOGO1"].x, board.components["LOGO1"].y), before)


    def test_restrict_regions_are_obstacles_and_grid_snapping_uses_brd_spacing(self):
        board = BoardData()
        comp = component("R1", 1)
        comp.y = 1.0
        board.components = {"R1": comp}
        board.restrict_top = [[(4, 4), (6, 4), (6, 6), (4, 6), (4, 4)]]
        board.grid_spacing_mm = 0.5
        optimizer = PlacementOptimizer(board)
        self.assertFalse(optimizer._single_candidate_is_valid(comp, (5.0, 5.0, 0.0, False)))
        optimizer.snap_to_grid = True
        self.assertAlmostEqual(optimizer._snap_coordinate(1.13), 1.0)
        self.assertAlmostEqual(optimizer._snap_coordinate(1.38), 1.5)

    def test_legacy_side_argument_does_not_disable_other_side_optimization(self):
        board = BoardData()
        top = component("R1", 2)
        bottom = component("R2", 8)
        bottom.mirror = True
        board.components = {"R1": top, "R2": bottom}
        optimizer = PlacementOptimizer(board)
        result = optimizer.optimize(max_iterations=10, max_evaluations=20, optimize_side="TOP", seed=2)
        self.assertGreater(result["evaluations"], 0)
        self.assertEqual(result["staged_components"], 2)
        self.assertEqual(result["accepted_layer_swaps"], 0)
        self.assertFalse(board.components["R1"].mirror)
        self.assertTrue(board.components["R2"].mirror)


    def test_layer_swaps_are_opt_in_and_apply_only_to_smd(self):
        class LayerSwapRng:
            def choice(self, values):
                return values[0]

            def choices(self, values, weights=None, k=1):
                return ["layer"] if "layer" in values else [values[0]]

            def random(self):
                return 0.0

        board = BoardData()
        smd = component("R1", 5)
        tht = component("J1", 10)
        tht.is_tht = True
        board.components = {"R1": smd, "J1": tht}
        optimizer = PlacementOptimizer(board)
        self.assertFalse(optimizer._single_candidate_is_valid(smd, (smd.x, smd.y, smd.rot, True)))
        optimizer.allow_layer_swaps = True
        self.assertTrue(optimizer._single_candidate_is_valid(smd, (smd.x, smd.y, smd.rot, True)))
        self.assertFalse(optimizer._single_candidate_is_valid(tht, (tht.x, tht.y, tht.rot, True)))
        with patch("optimizer.random.Random", return_value=LayerSwapRng()):
            result = optimizer.optimize(max_iterations=1, max_evaluations=1, allow_layer_swaps=True)
        self.assertEqual(result["accepted_layer_swaps"], 1)
        self.assertFalse(board.components["J1"].mirror)

    def test_layer_swap_requires_explicit_pure_smd_classification(self):
        board = BoardData()
        component_mixed = component("U1", 5)
        component_mixed.is_smd = False  # Mixed/unknown package must not be assumed SMD.
        board.components = {"U1": component_mixed}
        optimizer = PlacementOptimizer(board)
        optimizer.allow_layer_swaps = True
        self.assertFalse(optimizer._single_candidate_is_valid(
            component_mixed, (component_mixed.x, component_mixed.y, component_mixed.rot, True)))

    def test_compound_move_validation_is_transactional(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (30, 0), (30, 20), (0, 20), (0, 0)]]
        first = component("R1", 5)
        second = component("R2", 10)
        first.y = second.y = 5.0
        board.components = {"R1": first, "R2": second}
        optimizer = PlacementOptimizer(board)
        candidates = {
            "R1": (20.0, 10.0, 0.0, False),
            "R2": (5.0, 5.0, 0.0, False),
        }
        original = {name: (comp.x, comp.y) for name, comp in board.components.items()}
        self.assertTrue(optimizer._candidate_group_is_valid(candidates))
        self.assertEqual(original, {name: (comp.x, comp.y) for name, comp in board.components.items()})

    def test_virtual_staging_is_non_destructive_and_keeps_fixed_objects(self):
        board = BoardData()
        board.boundary_polygons = [[(0, 0), (20, 0), (20, 20), (0, 20), (0, 0)]]
        board.components = {
            "R1": component("R1", 5),
            "J1": component("J1", 10, locked=True),
            "LOGO1": component("LOGO1", 15),
        }
        board.orphan_components = {"LOGO1"}
        workspace = VirtualPlacementWorkspace(board)
        staged = workspace.stage_unlocked_components()
        self.assertIn("R1", workspace.staged_names)
        self.assertGreater(staged["R1"][0], 20)
        self.assertEqual(staged["J1"], (10.0, 0.0))
        self.assertEqual(staged["LOGO1"], (15.0, 0.0))
        self.assertEqual(board.components["R1"].x, 5.0)
        workspace.commit()
        self.assertEqual(board.components["R1"].x, 5.0, "Unplaced staged components must not be committed off-board")
        workspace.set_candidate("R1", 4.0, 4.0)
        workspace.commit()
        self.assertEqual((board.components["R1"].x, board.components["R1"].y), (4.0, 4.0))
        self.assertEqual(board.components["LOGO1"].x, 15.0)

    def test_optimizer_never_accepts_a_worse_swap(self):
        board = BoardData()
        board.components = {"R1": component("R1", 0), "R2": component("R2", 10)}
        board.signals = {"N1": NetSignal("N1", [
            NetConnection("R1", "1", 0, 0), NetConnection("R2", "1", 10, 0)
        ])}
        optimizer = PlacementOptimizer(board)
        before = optimizer.calculate_fitness()
        result = optimizer.optimize(max_iterations=10, max_evaluations=100)
        self.assertLessEqual(result["final_fitness"], before)


if __name__ == "__main__":
    unittest.main()
