import os
import tempfile
import unittest
import xml.etree.ElementTree as ET
from dru_parser import DesignRules
from geometry import ComponentData, NetConnection, BoardData, NetSignal
from optimizer import PlacementOptimizer
from parser import EagleBoardParser


class DesignRulesTests(unittest.TestCase):
    def test_loads_xml_dru_parameters_and_units(self):
        xml = '''<designrules name="test">
          <param name="mdSmdSmd" value="8mil"/>
          <param name="mdPadPad" value="10mil"/>
          <param name="mdCopperDimension" value="0.4mm"/>
          <param name="mdWireWire" value="6mil"/>
          <param name="mdDrill" value="10mil"/>
        </designrules>'''
        with tempfile.NamedTemporaryFile("w", suffix=".dru", encoding="utf-8", delete=False) as handle:
            handle.write(xml)
            path = handle.name
        try:
            rules = DesignRules()
            self.assertTrue(rules.load_from_dru_file(path))
            self.assertAlmostEqual(rules.clearance_comp_to_comp, 10 * 0.0254)
            self.assertAlmostEqual(rules.clearance_board_edge, 0.4)
            self.assertAlmostEqual(rules.clearance_track_to_track, 6 * 0.0254)
            self.assertAlmostEqual(rules.clearance_component_to_hole, 10 * 0.0254)
            self.assertEqual(rules.source_type, "FILE_DRU")
        finally:
            os.unlink(path)

    def test_legacy_key_value_dru_remains_supported(self):
        content = "mdSmdSmd=8mil\nmdCopperDimension=0.5mm\nmdWireWire=6mil\n"
        with tempfile.NamedTemporaryFile("w", suffix=".dru", encoding="utf-8", delete=False) as handle:
            handle.write(content)
            path = handle.name
        try:
            rules = DesignRules()
            self.assertTrue(rules.load_from_dru_file(path))
            self.assertAlmostEqual(rules.clearance_comp_to_comp, 8 * 0.0254)
            self.assertAlmostEqual(rules.clearance_board_edge, 0.5)
        finally:
            os.unlink(path)

    def test_invalid_unit_is_rejected(self):
        self.assertIsNone(DesignRules._parse_unit("not-a-unit"))
        self.assertAlmostEqual(DesignRules._parse_unit("1 inch"), 25.4)

    def test_board_net_classes_are_parsed(self):
        root = ET.fromstring('''<eagle><drawing><board>
          <classes><class number="1" name="Power" width="20mil" clearance="8mil"/></classes>
          <designrules><param name="mdWireWire" value="6mil"/></designrules>
        </board></drawing></eagle>''')
        rules = DesignRules()
        rules.parse_from_brd_xml(root)
        self.assertIn(1, rules.net_classes)
        self.assertAlmostEqual(rules.net_classes[1]["width"], 20 * 0.0254)
        self.assertAlmostEqual(rules.net_classes[1]["clearance"], 8 * 0.0254)


    def test_board_grid_and_top_bottom_restrictions_are_parsed(self):
        xml = '''<eagle><drawing>
          <grid distance="25" unitdist="mil" unit="mil"/>
          <board><plain>
            <rectangle x1="1" y1="1" x2="3" y2="3" layer="41"/>
            <rectangle x1="5" y1="1" x2="7" y2="3" layer="42"/>
            <rectangle x1="9" y1="1" x2="11" y2="3" layer="39"/>
            <rectangle x1="13" y1="1" x2="15" y2="3" layer="40"/>
          </plain><elements/><libraries/><signals/></board></drawing></eagle>'''
        with tempfile.NamedTemporaryFile("w", suffix=".brd", encoding="utf-8", delete=False) as handle:
            handle.write(xml)
            path = handle.name
        try:
            board = EagleBoardParser(path).extract_data()
            self.assertAlmostEqual(board.grid_spacing_mm, 25 * 0.0254)
            self.assertEqual(len(board.restrict_top), 1)
            self.assertEqual(len(board.restrict_bottom), 1)
            self.assertEqual(len(board.keepouts_top), 1)
            self.assertEqual(len(board.keepouts_bottom), 1)
        finally:
            os.unlink(path)


class PlacementCoordinateTests(unittest.TestCase):
    def test_optimizer_uses_absolute_pad_coordinates_without_transforming_twice(self):
        component = ComponentData(
            name="U1", library="test", package="pkg", x=10.0, y=20.0,
            rot=90.0, mirror=False, width=2.0, height=2.0,
            offset_x=0.0, offset_y=0.0,
        )
        connection = NetConnection(element="U1", pad="1", x=10.0, y=21.0)
        optimizer = PlacementOptimizer(BoardData())
        self.assertEqual(optimizer._get_absolute_pad_coords(component, connection), (10.0, 21.0))

    def test_ratsnest_uses_parsed_absolute_coordinates(self):
        board = BoardData()
        board.components["U1"] = ComponentData(
            name="U1", library="test", package="pkg", x=10.0, y=20.0,
            rot=90.0, mirror=False, width=2.0, height=2.0,
            offset_x=0.0, offset_y=0.0,
        )
        board.components["R1"] = ComponentData(
            name="R1", library="test", package="pkg", x=13.0, y=25.0,
            rot=0.0, mirror=False, width=2.0, height=2.0,
            offset_x=0.0, offset_y=0.0,
        )
        board.signals["N1"] = NetSignal(name="N1", connections=[
            NetConnection(element="U1", pad="1", x=10.0, y=21.0),
            NetConnection(element="R1", pad="1", x=13.0, y=25.0),
        ])
        self.assertAlmostEqual(PlacementOptimizer(board).calculate_ratsnest_length(), 5.0)


class BoardGeometryTests(unittest.TestCase):
    def test_component_outlines_do_not_pollute_board_outline(self):
        xml = '''<eagle><drawing><board>
          <plain>
            <wire x1="0" y1="0" x2="20" y2="0" layer="20"/>
            <wire x1="20" y1="0" x2="20" y2="10" layer="20"/>
            <wire x1="20" y1="10" x2="0" y2="10" layer="20"/>
            <wire x1="0" y1="10" x2="0" y2="0" layer="20"/>
          </plain>
          <libraries><library name="test"><packages><package name="pkg">
            <wire x1="-1" y1="-1" x2="1" y2="-1" layer="20"/>
            <wire x1="1" y1="-1" x2="1" y2="1" layer="20"/>
            <wire x1="1" y1="1" x2="-1" y2="1" layer="20"/>
            <wire x1="-1" y1="1" x2="-1" y2="-1" layer="20"/>
            <smd name="1" x="1" y="0" dx="1" dy="1" layer="1"/>
          </package></packages></library></libraries>
          <elements><element name="U1" library="test" package="pkg" x="10" y="20" rot="R90"/></elements>
          <signals><signal name="N1"><contactref element="U1" pad="1"/></signal></signals>
        </board></drawing></eagle>'''
        with tempfile.NamedTemporaryFile("w", suffix=".brd", encoding="utf-8", delete=False) as handle:
            handle.write(xml)
            path = handle.name
        try:
            board = EagleBoardParser(path).extract_data()
            self.assertEqual(len(board.boundary_polygons), 1)
            self.assertIn("U1", board.component_outlines)
            self.assertIn("test", board.packages)
            connection = board.signals["N1"].connections[0]
            self.assertAlmostEqual(connection.x, 10.0, places=6)
            self.assertAlmostEqual(connection.y, 21.0, places=6)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
