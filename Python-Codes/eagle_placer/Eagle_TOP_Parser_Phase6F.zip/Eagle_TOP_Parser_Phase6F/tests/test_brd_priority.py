import os
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import main
from geometry import BoardData, ComponentData, NetConnection, NetSignal, TrackSegment


class FakeLogger:
    def __init__(self):
        self.messages = []

    def info(self, message):
        self.messages.append(("INFO", message))

    def warning(self, message):
        self.messages.append(("WARNING", message))

    def error(self, message):
        self.messages.append(("ERROR", message))

    def success(self, message):
        self.messages.append(("SUCCESS", message))


class FakeGui:
    def __init__(self):
        self.rendered = False

    def _render(self, schematic_parts=None):
        self.rendered = True
        self.schematic_parts = schematic_parts


class FakeOptimizer:
    def __init__(self, board_data):
        self.board_data = board_data

    def calculate_ratsnest_length(self):
        return 0.0


class BRDPriorityWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.board_path = os.path.join(self.temp_dir.name, "design.brd")
        with open(self.board_path, "w", encoding="utf-8") as handle:
            handle.write("placeholder")

        self.board = BoardData()
        self.board.components["R1"] = ComponentData(
            name="R1", library="test", package="pkg", x=1.0, y=2.0,
            rot=0.0, mirror=False, width=1.0, height=1.0,
            offset_x=0.0, offset_y=0.0,
        )
        self.board.signals["N_BOARD"] = NetSignal(
            name="N_BOARD",
            connections=[NetConnection(element="R1", pad="1", x=1.0, y=2.0)],
        )

        self.app = main.EagleApp.__new__(main.EagleApp)
        self.app.window = None
        self.app.file_path = ""
        self.app.board_data = None
        self.app.optimizer = None
        self.app.schematic_parts = {}
        self.app.logger = FakeLogger()
        self.app.gui = FakeGui()

    def tearDown(self):
        self.temp_dir.cleanup()

    def _run_workflow(self, schematic_parts=None, parse_error=None):
        class FakeBoardParser:
            def __init__(self, path):
                pass

            def extract_data(self):
                return self_outer.board

        class FakeSchematicParser:
            def __init__(self, path):
                self.net_classes = {}
                if parse_error:
                    raise ValueError("synthetic schematic parse failure")

            def extract_schematic_data(self):
                return schematic_parts or {}

        self_outer = self
        with patch.object(main.filedialog, "askopenfilename", return_value=self.board_path), \
             patch.object(main, "EagleBoardParser", FakeBoardParser), \
             patch.object(main, "EagleSchematicParser", FakeSchematicParser), \
             patch.object(main, "PlacementOptimizer", FakeOptimizer), \
             patch.object(main.messagebox, "showwarning") as warning_dialog, \
             patch.object(main, "debug_print_schematic_entanglement"):
            self.app._open_file_impl()
        return warning_dialog

    def test_missing_schematic_does_not_block_board_load(self):
        warning_dialog = self._run_workflow()
        self.assertIs(self.app.board_data, self.board)
        self.assertIsInstance(self.app.optimizer, FakeOptimizer)
        self.assertTrue(self.app.gui.rendered)
        self.assertEqual(self.board.orphan_components, set())
        warning_dialog.assert_called_once()

    def test_empty_schematic_does_not_block_board_load(self):
        with open(os.path.splitext(self.board_path)[0] + ".sch", "w", encoding="utf-8") as handle:
            handle.write("placeholder")
        warning_dialog = self._run_workflow(schematic_parts={})
        self.assertIsInstance(self.app.optimizer, FakeOptimizer)
        self.assertTrue(self.app.gui.rendered)
        self.assertEqual(self.board.orphan_components, set())
        warning_dialog.assert_called_once()

    def test_inconsistent_schematic_does_not_block_board_load(self):
        with open(os.path.splitext(self.board_path)[0] + ".sch", "w", encoding="utf-8") as handle:
            handle.write("placeholder")
        part = SimpleNamespace(
            library="test", deviceset="resistor", value="10k", gates={},
            pad_to_pin_map={"1": "G$1.1"},
            net_by_pin={"G$1.1": "N_SCHEMATIC"},
            gate_pin_definitions={},
        )
        warning_dialog = self._run_workflow(schematic_parts={"R1": part})
        self.assertIsInstance(self.app.optimizer, FakeOptimizer)
        self.assertTrue(self.app.gui.rendered)
        warning_dialog.assert_called_once()
        self.assertTrue(any("inconsistencies" in message.lower() for _, message in self.app.logger.messages))

    def test_unreadable_schematic_does_not_block_board_load(self):
        with open(os.path.splitext(self.board_path)[0] + ".sch", "w", encoding="utf-8") as handle:
            handle.write("placeholder")
        warning_dialog = self._run_workflow(parse_error=True)
        self.assertIsInstance(self.app.optimizer, FakeOptimizer)
        self.assertTrue(self.app.gui.rendered)
        self.assertEqual(self.board.orphan_components, set())
        warning_dialog.assert_called_once()

    def test_geometry_only_board_is_loaded_with_warning(self):
        self.board.components.clear()
        self.board.signals.clear()
        self.board.tracks.append(TrackSegment(
            p1=(0.0, 0.0), p2=(10.0, 0.0), width=0.5, layer=1, signal_name="N1"
        ))
        warning_dialog = self._run_workflow()
        self.assertIs(self.app.board_data, self.board)
        self.assertTrue(self.app.gui.rendered)
        self.assertTrue(any("No component placements" in message for _, message in self.app.logger.messages))
        warning_dialog.assert_called_once()

    def test_empty_board_is_loaded_with_explicit_warning(self):
        self.board.components.clear()
        self.board.signals.clear()
        warning_dialog = self._run_workflow()
        self.assertIs(self.app.board_data, self.board)
        self.assertTrue(self.app.gui.rendered)
        self.assertTrue(any("no components or recognized board geometry" in message.lower() for _, message in self.app.logger.messages))
        warning_dialog.assert_called_once()


if __name__ == "__main__":
    unittest.main()
