import unittest
from geometry import BoardData, ComponentData
from optimizer import PlacementOptimizer


def part(name, x, locked=False, is_tht=False):
    return ComponentData(name=name, library="test", package="0402", x=float(x), y=5.0,
        rot=0.0, mirror=False, width=1.0, height=1.0, offset_x=0.0, offset_y=0.0,
        locked=locked, is_tht=is_tht, is_smd=not is_tht, deviceset="R")


class Phase6CVariableDepthTests(unittest.TestCase):
    def setUp(self):
        self.board = BoardData()
        self.board.boundary_polygons = [[(0, 0), (40, 0), (40, 20), (0, 20), (0, 0)]]
        self.board.components = {f"R{i}": part(f"R{i}", 3 + i * 4) for i in range(1, 5)}
        self.optimizer = PlacementOptimizer(self.board)

    def test_four_component_candidate_is_validated_atomically(self):
        candidates = {
            "R1": (25.0, 5.0, 0.0, False),
            "R2": (7.0, 5.0, 0.0, False),
            "R3": (11.0, 5.0, 0.0, False),
            "R4": (15.0, 5.0, 0.0, False),
        }
        before = {name: (c.x, c.y) for name, c in self.board.components.items()}
        self.assertTrue(self.optimizer._candidate_group_is_valid(candidates))
        self.assertEqual(before, {name: (c.x, c.y) for name, c in self.board.components.items()})

    def test_variable_depth_candidate_rejects_locked_member(self):
        self.board.components["R3"].locked = True
        candidates = {
            "R1": (25.0, 5.0, 0.0, False),
            "R2": (7.0, 5.0, 0.0, False),
            "R3": (11.0, 5.0, 0.0, False),
            "R4": (15.0, 5.0, 0.0, False),
        }
        self.assertFalse(self.optimizer._candidate_group_is_valid(candidates))

    def test_variable_depth_candidate_rejects_outside_outline(self):
        candidates = {
            "R1": (50.0, 5.0, 0.0, False),
            "R2": (7.0, 5.0, 0.0, False),
            "R3": (11.0, 5.0, 0.0, False),
            "R4": (15.0, 5.0, 0.0, False),
        }
        self.assertFalse(self.optimizer._candidate_group_is_valid(candidates))


if __name__ == "__main__":
    unittest.main()
