import os
import tempfile
import unittest
from types import SimpleNamespace

from geometry import BoardData, ComponentData, NetConnection, NetSignal
from main import check_schematic_board_consistency
from parser_schematic import EagleSchematicParser


class SchematicConsistencyTests(unittest.TestCase):
    def _make_board_and_part(self, schematic_net):
        board = BoardData()
        board.components["R1"] = ComponentData(
            name="R1", library="test", package="pkg", x=0.0, y=0.0,
            rot=0.0, mirror=False, width=1.0, height=1.0,
            offset_x=0.0, offset_y=0.0,
        )
        board.signals["N_BOARD"] = NetSignal(name="N_BOARD", connections=[
            NetConnection(element="R1", pad="1", x=0.0, y=0.0)
        ])
        part = SimpleNamespace(
            library="test",
            deviceset="resistor",
            pad_to_pin_map={"1": "G$1.1"},
            net_by_pin={"G$1.1": schematic_net},
            gate_pin_definitions={},
        )
        return board, {"R1": part}

    def test_board_schematic_net_mismatch_is_detected(self):
        board, parts = self._make_board_and_part("N_SCHEMATIC")
        self.assertFalse(check_schematic_board_consistency(board, parts))

    def test_matching_board_schematic_net_is_accepted(self):
        board, parts = self._make_board_and_part("N_BOARD")
        self.assertTrue(check_schematic_board_consistency(board, parts))


    def test_board_only_objects_are_reported_but_do_not_block_workflow(self):
        board, parts = self._make_board_and_part("N_BOARD")
        board.components["LOGO1"] = ComponentData(
            name="LOGO1", library="graphics", package="logo", x=5.0, y=5.0,
            rot=0.0, mirror=False, width=2.0, height=2.0, offset_x=0.0, offset_y=0.0,
        )
        self.assertTrue(check_schematic_board_consistency(board, parts))
        self.assertEqual(board.orphan_components, {"LOGO1"})

    def test_schematic_only_components_are_reported_without_blocking(self):
        board, parts = self._make_board_and_part("N_BOARD")
        parts["C_MISSING"] = SimpleNamespace(
            library="test", deviceset="capacitor", pad_to_pin_map={},
            net_by_pin={}, gate_pin_definitions={},
        )
        self.assertTrue(check_schematic_board_consistency(board, parts))
        self.assertEqual(board.schematic_only_components, {"C_MISSING"})

    def test_schematic_parser_extracts_pin_net_membership(self):
        xml = """<eagle><drawing><schematic>
          <parts><part name="R1" library="test" deviceset="resistor" device="" value="10k"/></parts>
          <libraries><library name="test">
            <symbols><symbol name="R"><pin name="1" swaplevel="0"/></symbol></symbols>
            <devicesets><deviceset name="resistor"><gates><gate name="G$1" symbol="R"/></gates>
              <devices><device name=""><connects><connect gate="G$1" pin="1" pad="1"/></connects></device></devices>
            </deviceset></devicesets>
          </library></libraries>
          <sheets><sheet><nets><net name="N1"><segment>
            <pinref part="R1" gate="G$1" pin="1"/>
          </segment></net></nets></sheet></sheets>
        </schematic></drawing></eagle>"""
        with tempfile.NamedTemporaryFile("w", suffix=".sch", encoding="utf-8", delete=False) as handle:
            handle.write(xml)
            path = handle.name
        try:
            parts = EagleSchematicParser(path).extract_schematic_data()
            self.assertEqual(parts["R1"].net_by_pin["G$1.1"], "N1")
        finally:
            os.unlink(path)

    def test_net_class_mismatch_is_detected(self):
        board, parts = self._make_board_and_part("N_BOARD")
        board.net_classes = {1: {"name": "Power", "width": 0.5, "clearance": 0.2}}
        schematic_classes = {1: SimpleNamespace(number=1, name="Power", width=0.4, clearance=0.2)}
        self.assertFalse(check_schematic_board_consistency(board, parts, schematic_net_classes=schematic_classes))

    def test_clearance_difference_does_not_create_net_class_mismatch(self):
        board, parts = self._make_board_and_part("N_BOARD")
        board.net_classes = {1: {"name": "Power", "width": 0.3048, "clearance": 0.1524}}
        schematic_classes = {
            1: SimpleNamespace(number=1, name="Power", width=0.3048, clearance=0.0)
        }
        self.assertTrue(
            check_schematic_board_consistency(
                board, parts, schematic_net_classes=schematic_classes
            )
        )

    def test_schematic_net_class_units_are_normalized(self):
        xml = """<eagle><drawing><schematic>
          <classes><class number="1" name="Power" width="20mil" clearance="8mil"/></classes>
        </schematic></drawing></eagle>"""
        with tempfile.NamedTemporaryFile("w", suffix=".sch", encoding="utf-8", delete=False) as handle:
            handle.write(xml)
            path = handle.name
        try:
            parser = EagleSchematicParser(path)
            parser.extract_schematic_data()
            self.assertAlmostEqual(parser.net_classes[1].width, 20 * 0.0254)
            self.assertAlmostEqual(parser.net_classes[1].clearance, 8 * 0.0254)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
