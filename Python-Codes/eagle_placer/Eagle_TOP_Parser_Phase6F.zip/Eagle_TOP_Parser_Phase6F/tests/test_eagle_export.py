import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from eagle_export import export_placement_pair


class EagleExportTests(unittest.TestCase):
    def test_exports_positions_preserves_inventory_and_copies_schematic(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source_brd = root / "source.brd"
            source_sch = root / "source.sch"
            output_brd = root / "optimized.brd"
            output_sch = root / "optimized.sch"
            source_brd.write_text(
                '<?xml version="1.0" encoding="utf-8"?>\n'
                '<!DOCTYPE eagle SYSTEM "eagle.dtd">\n'
                '<eagle><drawing><board><elements>'
                '<element name="U1" x="1" y="2" rot="R0"/>'
                '<element name="R1" x="3" y="4" rot="SMR90"/>'
                '</elements><signals><signal name="N1"/></signals></board></drawing></eagle>',
                encoding="utf-8",
            )
            schematic = '<?xml version="1.0"?><eagle><drawing><schematic/></drawing></eagle>'
            source_sch.write_text(schematic, encoding="utf-8")

            count = export_placement_pair(
                source_brd, source_sch, output_brd, output_sch,
                {"U1": (10.25, 20.5, 180, False), "R1": (30, 40, 270, True)},
            )

            self.assertEqual(count, 2)
            exported = ET.parse(output_brd).getroot()
            elements = {item.get("name"): item for item in exported.findall(".//board/elements/element")}
            self.assertEqual(elements["U1"].get("x"), "10.25")
            self.assertEqual(elements["U1"].get("y"), "20.5")
            self.assertEqual(elements["U1"].get("rot"), "R180")
            self.assertEqual(elements["R1"].get("rot"), "SMR270")
            self.assertEqual(set(elements), {"U1", "R1"})
            self.assertIn(b'<!DOCTYPE eagle SYSTEM "eagle.dtd">', output_brd.read_bytes())
            self.assertEqual(output_sch.read_text(encoding="utf-8"), schematic)
            self.assertEqual(source_brd.read_text(encoding="utf-8").count('x="1"'), 1)

    def test_rejects_missing_component_without_writing_outputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            brd = root / "source.brd"
            sch = root / "source.sch"
            out_brd = root / "out.brd"
            out_sch = root / "out.sch"
            brd.write_text('<eagle><drawing><board><elements><element name="U1"/></elements></board></drawing></eagle>')
            sch.write_text('<eagle><drawing><schematic/></drawing></eagle>')
            with self.assertRaisesRegex(ValueError, "missing from the source BRD"):
                export_placement_pair(brd, sch, out_brd, out_sch, {"U2": (1, 2, 0, False)})
            self.assertFalse(out_brd.exists())
            self.assertFalse(out_sch.exists())

    def test_rejects_boards_with_existing_routed_copper(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            brd = root / "source.brd"
            sch = root / "source.sch"
            brd.write_text(
                '<eagle><drawing><board><elements><element name="U1"/></elements>'
                '<signals><signal name="N1"><wire x1="0" y1="0" x2="1" y2="1" width="0.2" layer="1"/></signal></signals>'
                '</board></drawing></eagle>'
            )
            sch.write_text('<eagle><drawing><schematic/></drawing></eagle>')
            with self.assertRaisesRegex(ValueError, "already contains routed copper"):
                export_placement_pair(brd, sch, root / "out.brd", root / "out.sch", {"U1": (1, 2, 0, False)})

    def test_allows_unrouted_airwires_and_polygon_pours(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            brd = root / "source.brd"
            sch = root / "source.sch"
            brd.write_text(
                '<eagle><drawing><board><elements><element name="U1"/></elements>'
                '<signals><signal name="N1">'
                '<wire x1="0" y1="0" x2="1" y2="1" width="0" layer="19"/>'
                '<polygon width="0.2" layer="1" isolate="0.2">'
                '<vertex x="0" y="0"/><vertex x="2" y="0"/><vertex x="2" y="2"/>'
                '</polygon></signal></signals></board></drawing></eagle>',
                encoding="utf-8",
            )
            sch.write_text('<eagle><drawing><schematic/></drawing></eagle>')

            count = export_placement_pair(
                brd, sch, root / "out.brd", root / "out.sch",
                {"U1": (1, 2, 0, False)},
            )

            self.assertEqual(count, 1)
            self.assertTrue((root / "out.brd").is_file())
            self.assertTrue((root / "out.sch").is_file())

    def test_rejects_routed_vias_even_without_tracks(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            brd = root / "source.brd"
            sch = root / "source.sch"
            brd.write_text(
                '<eagle><drawing><board><elements><element name="U1"/></elements>'
                '<signals><signal name="N1"><via x="1" y="1" extent="1-16" drill="0.3"/></signal>'
                '</signals></board></drawing></eagle>',
                encoding="utf-8",
            )
            sch.write_text('<eagle><drawing><schematic/></drawing></eagle>')
            with self.assertRaisesRegex(ValueError, "already contains routed copper tracks or vias"):
                export_placement_pair(brd, sch, root / "out.brd", root / "out.sch", {"U1": (1, 2, 0, False)})

    def test_rejects_source_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            brd = root / "source.brd"
            sch = root / "source.sch"
            brd.write_text('<eagle><drawing><board><elements/></board></drawing></eagle>')
            sch.write_text('<eagle><drawing><schematic/></drawing></eagle>')
            with self.assertRaisesRegex(ValueError, "must not overwrite"):
                export_placement_pair(brd, sch, brd, sch, {})


if __name__ == "__main__":
    unittest.main()
