import unittest
from unittest.mock import patch

from geometry import BoardData, ComponentData
from optimizer import PlacementOptimizer


def component(name, x, *, locked=False):
    return ComponentData(
        name=name, library="test", package="0402", x=float(x), y=5.0,
        rot=0.0, mirror=False, width=1.0, height=1.0,
        offset_x=0.0, offset_y=0.0, locked=locked, is_tht=False,
        is_smd=True, deviceset="R",
    )


class DeterministicChainRandom:
    def choice(self, values):
        return values[0]

    def choices(self, population, weights=None, k=1):
        if tuple(population) == (2, 3, 4):
            return [2]
        if "chain" in population:
            return ["chain"]
        return [population[0]]

    def sample(self, population, k):
        return list(population[:k])

    def uniform(self, low, high):
        if low == 0.35:
            return high
        return 0.0

    def random(self):
        return 0.0

    def randrange(self, *args):
        return 0


class Phase6DBenchmarkTests(unittest.TestCase):
    def setUp(self):
        self.board = BoardData()
        self.board.boundary_polygons = [[(0, 0), (40, 0), (40, 20), (0, 20), (0, 0)]]
        self.board.components = {
            "R1": component("R1", 3),
            "R2": component("R2", 8),
            "R3": component("R3", 13),
            "R4": component("R4", 18),
        }
        self.optimizer = PlacementOptimizer(self.board)
        self.optimizer._strategic_translation_candidates = lambda _comp: [(28.0, 5.0)]
        initial_positions = {name: part.x for name, part in self.board.components.items()}

        def controlled_fitness(positions=None):
            if positions is not None:
                return 90.0
            moved = any(self.board.components[name].x != x for name, x in initial_positions.items())
            return 90.0 if moved else 100.0

        self.optimizer.calculate_fitness = controlled_fitness

    def test_accepted_chain_commits_all_members_and_records_depth_metrics(self):
        with patch("optimizer.random.Random", return_value=DeterministicChainRandom()):
            result = self.optimizer.optimize(
                max_iterations=1, max_evaluations=1, seed=11, plateau_window=1,
                monitor_callback=lambda _details: None,
            )

        self.assertEqual(self.board.components["R1"].x, 28.0)
        self.assertEqual(self.board.components["R2"].x, 3.0)
        self.assertEqual(result["accepted_compound_moves"], 1)
        self.assertEqual(result["action_stats"]["chain"]["accepted"], 1)
        self.assertEqual(result["chain_depth_stats"][2]["accepted"], 1)
        self.assertGreaterEqual(result["elapsed_seconds"], 0.0)
        self.assertTrue(result["benchmark_history"])
        self.assertIn("action_stats", result["benchmark_history"][-1])

    def test_monitor_checkpoint_contains_per_action_statistics(self):
        checkpoints = []
        with patch("optimizer.random.Random", return_value=DeterministicChainRandom()):
            self.optimizer.optimize(
                max_iterations=1, max_evaluations=1, seed=11, plateau_window=1,
                monitor_callback=checkpoints.append,
            )
        self.assertEqual(len(checkpoints), 1)
        self.assertIn("chain", checkpoints[0]["action_stats"])
        self.assertIn(2, checkpoints[0]["chain_depth_stats"])
        self.assertIn("elapsed_seconds", checkpoints[0])

    def test_auto_stop_triggers_only_after_configured_plateau(self):
        self.optimizer.calculate_fitness = lambda positions=None: 100.0
        with patch("optimizer.random.Random", return_value=DeterministicChainRandom()):
            result = self.optimizer.optimize(
                max_iterations=10, max_evaluations=10, seed=11, plateau_window=1,
                plateau_threshold_percent=0.01, auto_stop_enabled=True,
                auto_stop_min_seconds=0, auto_stop_patience=1,
                monitor_callback=lambda _details: None,
            )
        self.assertEqual(result["evaluations"], 1)
        self.assertTrue(result["auto_stop_enabled"])
        self.assertIn("Automatic stop:", result["auto_stop_reason"])
        self.assertIn("Automatic stop:", result["status"])

    def test_adaptive_strategy_weights_are_reported(self):
        checkpoints = []
        with patch("optimizer.random.Random", return_value=DeterministicChainRandom()):
            result = self.optimizer.optimize(
                max_iterations=2, max_evaluations=2, seed=11, plateau_window=1,
                monitor_callback=checkpoints.append, adaptive_strategy=True,
            )
        self.assertTrue(result["adaptive_strategy"])
        self.assertIn("move", result["strategy_weights"])
        self.assertTrue(result["strategy_weight_history"])
        self.assertIn("strategy_weights", checkpoints[0])


if __name__ == "__main__":
    unittest.main()
