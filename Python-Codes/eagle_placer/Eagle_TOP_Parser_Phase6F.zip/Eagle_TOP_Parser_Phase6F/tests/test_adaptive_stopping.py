import unittest
from geometry import BoardData, ComponentData
from optimizer import PlacementOptimizer


def make_board():
    board = BoardData()
    board.components = {
        "R1": ComponentData(
            name="R1", library="passives", package="R_0603", x=10.0, y=10.0,
            rot=0.0, mirror=False, width=1.6, height=0.8,
            offset_x=0.0, offset_y=0.0, locked=False, is_tht=False,
        )
    }
    return board


class AdaptiveStoppingTests(unittest.TestCase):
    def test_plateau_prompt_can_stop_and_preserve_best_state(self):
        board = make_board()
        optimizer = PlacementOptimizer(board)
        original = (board.components["R1"].x, board.components["R1"].y,
                    board.components["R1"].rot, board.components["R1"].mirror)
        prompts = []

        def on_plateau(details):
            prompts.append(details)
            return "stop"

        result = optimizer.optimize(
            max_iterations=100, max_evaluations=20, plateau_callback=on_plateau,
            plateau_window=1, plateau_threshold_percent=100.0, plateau_patience=1, seed=2,
        )

        self.assertEqual(len(prompts), 1)
        self.assertIn("Stopped after negligible improvement", result["status"])
        self.assertLessEqual(result["evaluations"], 1)
        self.assertEqual(
            (board.components["R1"].x, board.components["R1"].y,
             board.components["R1"].rot, board.components["R1"].mirror),
            original,
        )

    def test_continue_to_max_disables_future_plateau_prompts(self):
        optimizer = PlacementOptimizer(make_board())
        prompts = []

        def on_plateau(details):
            prompts.append(details)
            return "max"

        result = optimizer.optimize(
            max_iterations=10, max_evaluations=7, plateau_callback=on_plateau,
            plateau_window=1, plateau_threshold_percent=100.0, plateau_patience=1, seed=2,
        )

        self.assertEqual(len(prompts), 1)
        self.assertEqual(result["evaluations"], 7)
        self.assertIn("Evaluation budget reached", result["status"])
        self.assertGreaterEqual(result["plateau_checks"], 1)

    def test_evaluation_budget_is_enforced(self):
        result = PlacementOptimizer(make_board()).optimize(
            max_iterations=100, max_evaluations=4, seed=3,
        )
        self.assertLessEqual(result["evaluations"], 4)
        self.assertEqual(result["evaluations"], 4)

    def test_live_monitor_reports_checkpoints_without_stopping_search(self):
        optimizer = PlacementOptimizer(make_board())
        checkpoints = []
        result = optimizer.optimize(
            max_iterations=12,
            max_evaluations=12,
            monitor_callback=checkpoints.append,
            plateau_window=2,
            plateau_threshold_percent=100.0,
            plateau_patience=1,
            seed=3,
        )

        self.assertEqual(result["evaluations"], 12)
        self.assertEqual(len(checkpoints), 6)
        self.assertEqual(checkpoints[-1]["evaluations"], 12)
        self.assertIn("total_improvement_percent", checkpoints[-1])
        self.assertTrue(checkpoints[0]["stop_recommended"])
        self.assertIn("Evaluation budget reached", result["status"])


if __name__ == "__main__":
    unittest.main()
